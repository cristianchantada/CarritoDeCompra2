package com.cristian.carrito.utils;

import javax.swing.JOptionPane;

public class Mensaje {
	static public void verMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
}
